package com.yse.dev.Service;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yse.dev.DTO.LoginDto;
import com.yse.dev.DTO.MemberDto;
import com.yse.dev.DTO.ProfileDto;
import com.yse.dev.Entity.Member;
import com.yse.dev.Repository.MemberRepository;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MemberService {

    private final MemberRepository memberRepository;


    // 회원가입
    @Transactional
    public void signup(MemberDto memberDto) {

        if (isUserIdDuplicate(memberDto.getUserId())) {
            throw new IllegalArgumentException(
                    "이미 사용 중인 아이디입니다."
            );
        }

        if (isNicknameDuplicate(memberDto.getNickname())) {
            throw new IllegalArgumentException(
                    "이미 사용 중인 닉네임입니다."
            );
        }

        Member member =
                Member.toEntity(memberDto);

        memberRepository.save(member);
    }


    // 로그인
    @Transactional(readOnly = true)
    public Member login(LoginDto loginDto) {

        // 아이디로 회원 찾기
        Member member =
                memberRepository
                    .findByUserId(loginDto.getUserId())
                    .orElseThrow(() ->
                        new IllegalArgumentException(
                            "존재하지 않는 아이디입니다."
                        )
                    );


        // 비밀번호 비교
        if (!member.getPassword()
                .equals(loginDto.getPassword())) {

            throw new IllegalArgumentException(
                    "비밀번호가 일치하지 않습니다."
            );
        }


        // 로그인 성공한 회원 반환
        return member;
    }


 // 프로필 수정
    @Transactional
    public void updateProfile(
            String userId,
            ProfileDto profileDto) {

        Member member = memberRepository
                .findByUserId(userId)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "회원을 찾을 수 없습니다."
                        ));

        // 닉네임 변경
        if (profileDto.getNickname() != null
                && !profileDto.getNickname().trim().isEmpty()) {

            // 다른 회원이 사용 중인 닉네임인지 확인
            if (!member.getNickname().equals(profileDto.getNickname())
                    && memberRepository.existsByNickname(
                            profileDto.getNickname())) {

                throw new IllegalArgumentException(
                        "이미 사용 중인 닉네임입니다."
                );
            }

            member.setNickname(
                    profileDto.getNickname().trim()
            );
        }

        // 비밀번호는 입력했을 때만 변경
        if (profileDto.getPassword() != null
                && !profileDto.getPassword().trim().isEmpty()) {

            member.setPassword(
                    profileDto.getPassword()
            );
        }
    }


 // 회원 탈퇴
    @Transactional
    public void withdraw(String userId) {

        Member member = memberRepository
                .findByUserId(userId)
                .orElseThrow(() ->
                        new IllegalArgumentException(
                                "회원을 찾을 수 없습니다."
                        ));

        memberRepository.delete(member);

        // DB에 즉시 반영
        memberRepository.flush();
    }


    // 아이디 중복확인
    @Transactional(readOnly = true)
    public boolean isUserIdDuplicate(
            String userId) {

        return memberRepository
                .existsByUserId(userId);
    }


    // 닉네임 중복확인
    @Transactional(readOnly = true)
    public boolean isNicknameDuplicate(
            String nickname) {

        return memberRepository
                .existsByNickname(nickname);
    }

}