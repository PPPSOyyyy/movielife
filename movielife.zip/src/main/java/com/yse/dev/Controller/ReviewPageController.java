package com.yse.dev.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class ReviewPageController {

    @GetMapping("/review")
    public String review(HttpSession session) {

        String userId = (String) session.getAttribute("loginUserId");

        // 로그인하지 않은 경우
        if (userId == null) {
            return "redirect:/login?required=true";
        }

        // 로그인한 경우
        return "review";
    }
}