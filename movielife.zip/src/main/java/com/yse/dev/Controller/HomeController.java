package com.yse.dev.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpSession;

@Controller
public class HomeController {


		@GetMapping("/")
		public String Home() {
			return "index";
		}
		
		@GetMapping("/movie-detail")
		public String moviedetailpage() {
			return "movie-detail";
		}
		@GetMapping("/movie-list")
		public String movielistpage() {
			return "movie-list";
		}
		@GetMapping("/movie-recommend")
		public String movierecommendpage() {
			return "movie-recommend";
		}
		@GetMapping("/ott")
		public String ottpage() {
			return "ott";
		}
		@GetMapping("/popular")
		public String popularpage() {
			return "popular";
		}
		
    @GetMapping("/signup")
    public String signupPage() {
        return "signup";
    }

    @GetMapping("/login")
    public String loginPage() {
        return "login";
    }

    @GetMapping("/mypage")
    public String mypage(HttpSession session) {

        String userId = (String) session.getAttribute("loginUserId");

        if (userId == null) {
            return "redirect:/login?required=true";
        }

        return "mypage";
    }
    @GetMapping("/favorite-movies")
    public String favoriteMoviesPage(HttpSession session) {

        String userId = (String) session.getAttribute("loginUserId");

        // 로그인하지 않은 경우
        if (userId == null) {
            return "redirect:/login?required=true";
        }

        return "favorite-movies";
    }
    
    @GetMapping("/my-reviews")
    public String myReviewsPage() {
        return "my-reviews";
    }
    
    @GetMapping("/profile")
    public String profilePage(HttpSession session) {

        String userId =
                (String) session.getAttribute("loginUserId");

        if (userId == null) {
            return "redirect:/login?required=true";
        }

        return "profile";
    }
}